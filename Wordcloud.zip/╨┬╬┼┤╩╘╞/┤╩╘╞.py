from wordcloud import WordCloud
import PIL.Image as image
import pandas as pd
import numpy as np
import jieba
from jieba import analyse

with open('新闻.txt','r',encoding='utf-8') as f:
    df = f.read()
text = ''
text += df
print(text)


def words():
    words = jieba.lcut(text)
    counts = {}
    for word in words:
        if len(word) == 1:
            continue
        else:
            rword = word
        counts[rword] = counts.get(rword,0) + 1.
    items = list(counts.items())
    items.sort(key = lambda x:x[1],reverse=True)
    for i in range(200):
        word,count = items[i]
        with open('新闻词频.txt', 'a') as f:
            f.write(word+'\t' + str(int(count)) + '\n')
        print("{0:<10}{1:>5}".format(word,int(count)))


def wordcloud():
    split = jieba.cut(text
                      , cut_all=False
                      )  # False精准模式分词、True全模式分词
    words = ' '.join(split)
    mask = np.array(image.open("图片.jpg"))
    wordcloud = WordCloud(background_color="white", max_words=200, scale=4,
                          stopwords=(
                              '为', '和', '在', '都', '是', '我', '把', '的', '了', '与', '他', '都', '到', '来', '一些', '人', '什么',
                              '对',
                              '过',
                              '又', '也', '你', '不', '说', '她', '这', '也'
                              , '有'
                              , '才'
                              , '上'
                              , '去'
                              , '现在'
                              , '呢'
                              , '就'
                              , '一个'
                              , '着'
                              , '里'
                              , '书'
                              , '而'
                              , '看'
                              , '还'
                              , '吃'
                              , '给'
                              , '已经'
                              , '有点'
                              , '好'
                              , '那'
                              , '并'
                              , '大'
                              , '叫'),
                          max_font_size=40, random_state=42, mask=mask,
                          # 图片上的显示的字体  msyh.ttc微软雅黑  SIMYOU.TTF幼圆
                          font_path="C:\\Windows\\Fonts\\SIMYOU.TTF"
                          ).generate(words)
    image_produce = wordcloud.to_image()
    image_produce.show()
    wordcloud.to_file("新闻词云.jpg")
    print('生成词云成功！')


if __name__ == '__main__':
    words()   # 词频
    wordcloud()   # 词云
