import requests
from lxml import etree
import pandas as pd
import json
null = ''

headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.67 Safari/537.36'
    }  # 构造浏览器的请求头


def crawl_url(id):
    url = 'https://v2.sohu.com/public-api/feed?scene=CATEGORY&sceneId=1460&page={}&size=20&callback=jQuery112400417156247790218_1655559935737&_=1655559935763'.format(id)
    r = requests.get(url,headers=headers).text
    r = r.split('(')[1].split(')')[0]
    r = json.loads(r)

    for i in r:
        id = i['id']
        authorId = i['authorId']
        url = 'https://www.sohu.com/a/{}_{}'.format(id,authorId)
        crawl_page(url)
        print(url)


def crawl_page(url):
    # url = 'https://www.sohu.com/a/558631854_267106'
    r = requests.get(url, headers=headers).text
    # print(r)
    r = etree.HTML(r)
    text = ''
    ps = r.xpath('//*[@id="mp-editor"]/p')
    # print(len(ps))
    for i in ps[:-9]:
        try:
            inf = i.xpath('.//text()')[0]
            inf = inf.strip()

            text += inf
        except:
            pass
    text = text.replace('原标题：','').replace('\n','')
    if text != '':
        with open('新闻.txt','a', encoding='utf-8') as f:
            f.write(text + '\n')


if __name__ == '__main__':
    for i in range(1,6):
        crawl_url(i)


